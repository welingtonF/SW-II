// Elementos da página
const btnContadorCarrinho = document.querySelector('btn-carrinho');
const carrinho = document.querySelector('carrinho-lateral');
const itensCarrinho = document.querySelector('itens-carrinho');
const totalCarrinho = document.querySelector('total-carrinho');
const contadorQuantidade = document.querySelector('contador-quantidade');
btnFinalizar = document.getElementById('btn-finalizar')

let carrinhoProdutos = {};

contadorQuantidade.style.display = 'none';

// Função para formatar preço para real brasileiro
function formatarPreco(valor) {
    return valor.toLocaleString('pt-BR', {
        style: 'currency',
        currency: 'BRL'
    });
}

function configurarBotoesAdicionarCarrinho() {
    document.querySelectorAll('.botao-carrinho').forEach((botao, index) => {
        botao.addEvent ('click', ()  => {
            const produtoEl = botao.closest('.produto');

            const descricao = produtoEl.querySelector('.descricao').textContent.trim();
            const preco = parseFloat(precoTexto.replace('R$', '').replace('.', '').replace(',', '.'));
            const imgEl = produtoEl.querySelector('img');
            const imgSrc = imgEl ? imgEl.src : '';

            if (carrinhoProdutos[index]) {
                carrinhoProdutos[index].quantidade++;
            } else {
                carrinhoProdutos[index] = {
                    descricao,
                    preco,
                    img: imgSrc,
                    quantidade:1
                };
            }

            atualizarCarrinho();
            carrinho.classList.add('aberto');
        });
    });
}

function atualizarCarrinho() {
    itensCarrinho.innerHTML = '';
    let total = 0;
    let quantidadeTotal = 0;

    for (const id in carrinho) {
        const item = carrinhoProdutos[id];
        const subtotal = item.preco * item.quantidade;
        total += subtotal;
        quantidadeTotal += item.quantidade;

        const divItem = document.createElement('div');
        divItem.classList.add('item-carrinho');
        divItem.innerHTML = `
        <img src="${item.img}" alt="${item.descricao}" />
                <div class="item-carrinho-info">
                    <p class="descricao">${item.descricao}</p>
                    <p class="preco">${formatarPreco(item.preco)} | <span class="quantidade">${item.quantidade}</span> - ${formatarPreco(subtotal)}</p>
                    <div class="quantidade-container">
                        <button class="btn-quantidade" data-id="${id}" data-acao="diminuir">-</button>
                        <span>${item.quantidade}</span>
                        <button class="btn-quantidade" data-id="${id}" data-acao="aumentar">+</button>
                    </div>
                </div>
            `;
            itensCarrinho.appendChild(divItem);
  
        };

    totalCarrinho.textContent = `Total: ${formatarPreco(total)}`;
    contadorQuantidade.textContent = quantidadeTotal;
    contadorQuantidade.style.display = quantidadeTotal > 0 ? 'inline-block' : 'none';

    // Reconfigura os botões a + e - de quantidade
    configurarBotoesQuantidade();
    }




// Configura os eventos de alteração de quantidade dos produtos no carrinho
function configurarBotoesQuantidade() {
document.querySelectorAll('.btn-quantidade').forEach(btn => {
    btn.addEventListener('click', () => {
        const id = btn.getAttribute('data-id');
        const acao = btn.getAttribute('data-acao');

        if (acao === 'aumentar') {
            carrinhoProdutos[id].quantidade++;
        } else {
            carrinhoProdutos[id].quantidade--;
            if (carrinhoProdutos[id].quantidade < 1) {
                delete carrinhoProdutos[id];
            }
        }

        // Atualiza o carrinho após mudança
        atualizarCarrinho();
    });
});
}

// Alterna a visibilidade do carrinho lateral
function configurarBotaoAbrirFecharCarrinho() {
btnContadorCarrinho.addEventListener('click', () => {
    carrinho.classList.toggle('aberto');
});
}

// Redireciona para a página de finalização da compra
function configurarAcaoFinalizarCompra() {
btnFinalizar.addEventListener('click', () => {
    window.location.href = 'finalizar.html';
});
}

// Função de inicialização do sistema de carrinho
function inicializarCarrinho() {
configurarEventosAdicionarCarrinho();
configurarBotaoAbrirFecharCarrinho();
configurarAcaoFinalizarCompra();
}

// Inicializa tudo
inicializarCarrinho();

// Carrossel
const carrossel = document.querySelector('.carrossel');
const imagens = document.querySelectorAll('.carrossel img');
const btnAnterior = document.querySelector('.seta-anterior');
const btnProximo = document.querySelector('.seta-proximo');
let indiceAtual = 0;

function atualizarCarrossel() {
    carrossel.style.transform = `translateX(-${indiceAtual * 100}%)`;
}

btnAnterior.addEventListener('click', () => {
    indiceAtual = (indiceAtual === 0) ? imagens.length - 1 : indiceAtual - 1;
    atualizarCarrossel();
});

btnProximo.addEventListener('click', () => {
    indiceAtual = (indiceAtual === imagens.length - 1) ? 0 : indiceAtual + 1;
    atualizarCarrossel();
});
