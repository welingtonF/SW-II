// Elementos da página
const btnContadorCarrinho = document.querySelector('btn-carrinho');
const carrinho = document.querySelector('carrinho-lateral');
const itensCarrinho = document.querySelector('itens-carrinho');
const totalCarrinho = document.querySelector('total-carrinho');
const contadorQuantidade = document.querySelector('contador-quantidade');
btnFinalizar = document.getElementById('btn-finalizar')

let carrinhoProdutos = {};

contadorQuantidade.style.display = 'none';

// Função para formatar preço para real brasileiro
function formatarPreco(valor) {
    return valor.toLocaleString('pt-BR', {
        style: 'currency',
        currency: 'BRL'
    });
}

function configurarBotoesAdicionarCarrinho() {
    document.querySelectorAll('.botao-carrinho').forEach((botao, index) => {
        botao.addEvent ('click', ()  => {
            const produtoEl = botao.closest('.produto');

            const descricao = produtoEl.querySelector('.descricao').textContent.trim();
            const preco = parseFloat(precoTexto.replace('R$', '').replace('.', '').replace(',', '.'));
            const imgEl = produtoEl.querySelector('img');
            const imgSrc = imgEl ? imgEl.src : '';

            if (carrinhoProdutos[index]) {
                carrinhoProdutos[index].quantidade++;
            } else {
                carrinhoProdutos[index] = {
                    descricao,
                    preco,
                    img: imgSrc,
                    quantidade:1
                };
            }

            atualizarCarrinho();
            carrinho.classList.add('aberto');
        });
    });
}

function atualizarCarrinho() {
    itensCarrinho.innerHTML = '';
    let total = 0;
    let quantidadeTotal = 0;

    for (const id in carrinho) {
        const item = carrinhoProdutos[id];
        const subtotal = item.preco * item.quantidade;
        total += subtotal;
        quantidadeTotal += item.quantidade;

        const divItem = document.createElement('div');
        divItem.classList.add('item-carrinho');
        divItem.innerHTML = `
        <img src="${item.img}" alt="${item.descricao}" />
        <div class="item-carrinho-info">
        
        `;
    };
}