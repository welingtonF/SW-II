create table usuario (
nome varchar(150) not null,
email varchar(100) not null,
telefone varchar(15) not null,
cpf char(11) not null,
senha varchar(266) not null,
primary key(cpf));